# Layout Banner — ChatGPT Prompt Builder — Cách dùng

Biến brief event (docx/xlsx/text) thành MỘT prompt ChatGPT để tạo banner key-art hi-fi cho Lineage2M: tự phân loại Education/Sales, chọn mẫu layout, viết copy tiếng Anh chuẩn game-term, kèm bảng handoff VN cho designer. Có sẵn đường low-fi (PPTX zone-map) khi chưa có asset.

## Cách A — Cài để dùng lại nhiều lần (khuyến nghị)
1. Mở Claude.ai → **Settings > Capabilities** (hoặc **Customize > Skills**).
2. Bấm **Upload** → chọn file `layout-infographic.zip` bạn vừa tải về.
3. Skill **layout-infographic** xuất hiện trong danh sách. Xong — chỉ cần đưa brief event là chạy.

## Cách B — Dùng 1 lần (luôn là bản mới nhất)
1. Kéo `SKILL.md` (+ thư mục `prompts/`) trong gói này vào một đoạn chat Claude/Cowork.
2. Gõ: *"Làm theo skill này để tạo banner từ brief đính kèm."*
3. Không lo cache lệch version — bạn đang dùng đúng file vừa tải.

## Ghi chú
- Tải lại bản mới trên hub mỗi khi badge **version** trên card đổi.
- Nội dung tham khảo sâu (nếu có) nằm trong thư mục `reference/`.
- Skill này do TuanQG maintain. Góp ý / yêu cầu cải tiến → gửi TuanQG.
