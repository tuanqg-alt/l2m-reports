---
name: wording-vn
description: >
  Viết lại câu chữ tiếng Việt cho TỰ NHIÊN và CÔ ĐỌNG, không lộ mùi AI, giữ nguyên
  100% nội dung (không thêm ý, không bớt ý, không đổi số liệu hay thuật ngữ).
  LUÔN dùng khi người dùng nói: "wording lại", "viết lại cho tự nhiên", "bỏ mùi AI",
  "đọc như người viết", "gọt lại câu chữ", "cô đọng lại", "chỗ này nghe máy quá",
  "văn này khô quá", "viết lại tự nhiên hơn", hoặc chê một đoạn văn nghe như máy viết.
  CŨNG tự dùng khi vừa soạn nội dung tiếng Việt hướng tới người đọc và dài từ 80 từ
  trở lên — thông báo event, patch note gửi người chơi, mail hoặc tin nhắn gửi đối tác
  và team, post fanpage, caption, copy banner, phần diễn giải trong báo cáo, nội dung
  slide. KHÔNG dùng cho bảng số liệu, log, output script, code, hay bản dịch có ràng
  buộc thuật ngữ. Kèm bộ 10 luật viết, bảng 8 nhóm cụm từ lộ AI với bản thay thế, và
  script chấm điểm mùi AI 0-100 để đo trước/sau thay vì nói cảm tính.
  Pilot tiếng Việt; khung đã chừa chỗ cắm thêm ngôn ngữ khác.
version: 1.1
---

# ✍️ wording-vn — Viết lại văn phong cho tự nhiên (pilot: Tiếng Việt)

> Version: 1.1 | Updated: 2026-08-28 | Author: TuanQG × Claude
> Vị trí: `_framework/skills/wording-vn/` — dùng chéo mọi area, git-tracked, chạy được ở mọi máy pull workspace về.
> Ngôn ngữ đang hỗ trợ: **VI (pilot)**. Khung đã chừa chỗ cắm thêm — xem §7.

---

## 1. Mô tả

Skill này **không viết nội dung mới**. Nó nhận một đoạn văn đã có (thường do Claude viết) và **viết lại câu chữ** sao cho:

- **Tự nhiên** — đọc như người Việt viết, không lộ mùi AI
- **Cô đọng** — bỏ được chữ nào mà nghĩa không đổi thì bỏ chữ đó
- **Giữ nguyên 100% nội dung** — không thêm ý, không bớt ý, không đổi số

Ranh giới quan trọng: *đổi cách nói, không đổi điều được nói.* Nếu bản gốc sai nội dung, đó là việc của `content-crosscheck`, không phải của skill này.

---

## 2. Khi nào chạy

**Chạy khi TuanQG gọi tên** (bất kỳ cụm nào dưới đây):

`"wording lại"` · `"viết lại cho tự nhiên"` · `"bỏ mùi AI"` · `"đọc như người viết"` · `"gọt lại câu chữ"` · `"cô đọng lại"` · `"chỗ này nghe máy quá"` · `"wording-vn"`

**Tự bật (không cần gọi)** khi Claude vừa sinh nội dung tiếng Việt **hướng tới người đọc**:

| Loại nội dung | Tự bật? |
|---|---|
| Thông báo event / patch note gửi người chơi | ✅ |
| Mail, tin nhắn, message gửi đối tác / team | ✅ |
| Post fanpage, caption, copy banner | ✅ |
| Phần diễn giải/nhận định trong report (PUM, MKT, GameOps) | ✅ chỉ phần chữ, KHÔNG đụng số |
| Slide nội dung thuyết trình | ✅ |
| Bảng số liệu, log, output script, code | ❌ |
| Chat qua lại ngắn trong session | ❌ |
| Bản dịch có ràng buộc term (dùng `l2m-termbase-localization`) | ❌ — skill kia lo |

**Ngưỡng tự bật:** đoạn văn ≥ 80 từ tiếng Việt. Ngắn hơn thì viết đúng ngay từ đầu, không cần vòng gọt.

---

## 3. Ba luật bất di bất dịch

1. **Không đụng vào sự thật.** Số, ngày, tên riêng, tên game, tên class/item, đơn vị tiền, % — copy y nguyên. Nếu bản gốc ghi `$1,313,556` thì bản mới cũng phải là `$1,313,556`, không được làm tròn thành "hơn 1,3 triệu USD" trừ khi TuanQG bảo thế.
2. **Không thêm ý, không bớt ý.** Cắt chữ thừa ≠ cắt thông tin. Câu "Doanh thu giảm 16,4% do sụt DAU sau 15/07" rút thành "Doanh thu giảm 16,4%" là **sai** — mất nguyên nhân.
3. **Thuật ngữ L2M phải tra, không đoán.** Gặp term game → `03_Glossary-Termbase/.../lookup_term.py`. Skill này không có quyền tự đặt lại tên skill/item.

---

## 4. Quy trình 3 bước

### Bước 1 — CHẨN ĐOÁN (đo trước, đừng cảm tính)

```bash
python3 _framework/skills/wording-vn/scripts/ai_score.py --file <đường dẫn>
# hoặc đọc từ stdin:
cat bai.md | python3 _framework/skills/wording-vn/scripts/ai_score.py
```

> 📦 Nếu đang chạy từ **gói skill tải về** (không có workspace) thì đường dẫn ngắn lại còn `scripts/ai_score.py`. Đoạn dài ở trên là đường dẫn trong workspace.

Script trả về **điểm mùi AI 0–100** (thấp = tự nhiên) kèm bảng chi tiết từng chỉ báo và danh sách cụm bị bắt kèm vị trí dòng.

Đọc thêm `reference/rules_vi.md` §chẩn đoán để soi những thứ script không đo được (giọng, khoảng cách với người đọc, thông tin bị chôn ở cuối đoạn).

### Bước 2 — VIẾT LẠI

Áp `reference/rules_vi.md` (10 luật viết) + `reference/blacklist_vi.md` (bảng cụm → bản thay).

Thứ tự ưu tiên khi phải đánh đổi: **đúng nghĩa > tự nhiên > ngắn**. Không bao giờ hy sinh nghĩa để lấy nhịp câu đẹp.

### Bước 3 — ĐỐI CHIẾU (bắt buộc, không được bỏ)

Trình cho TuanQG **3 thứ**:

1. **Bảng điểm trước/sau** — chạy lại script trên bản mới:
   ```bash
   python3 _framework/skills/wording-vn/scripts/ai_score.py --before goc.md --after moi.md
   ```
   Dưới 20 từ văn xuôi thì script từ chối chấm và nói thẳng — đoạn ngắn quá thì đọc bằng mắt, đừng bịa điểm.
2. **Bảng đối chiếu ý** — mỗi ý của bản gốc một dòng, đánh dấu ✅ còn / ⚠️ đổi cách diễn đạt / 🔴 mất. Có 🔴 nào = chưa xong, phải sửa.
3. **Bản viết lại** — dán nguyên văn để TuanQG đọc.

> ⚠️ Điểm số chỉ là **cái phanh**, không phải mục tiêu. Điểm 5/100 mà đọc lên trúc trắc thì bản đó hỏng. Người quyết cuối cùng là TuanQG, không phải script.

---

## 5. Định dạng bàn giao chuẩn

Dán nguyên bảng script in ra (6 chỉ báo, không tự chế thêm dòng), rồi mới tới đối chiếu ý và bản viết lại:

```
📊 ĐIỂM MÙI AI: 47.3 → 22.7  (-24.6)  ✅ tốt hơn

Chỉ báo                       Trước      Sau     Ngưỡng tốt
-----------------------------------------------------------
Cụm blacklist /100 từ          9.94      0.0          ≤ 0.5
Độ dài câu TB (từ)             19.3     12.5          11–22
Độ lệch nhịp câu                5.2      1.8          ≥ 7.0
Câu mở bằng liên từ             33%       0%          ≤ 25%
Em dash /1000 ký tự             0.0     3.79          ≤ 3.0
Bullet đều tăm tắp              0.0      0.0          ≤ 0.4

Số từ: 116 → 50  (-57%)

🔍 ĐỐI CHIẾU Ý: 4/4 ✅ · 0 mất · 0 thêm

--- BẢN VIẾT LẠI ---
<nội dung>
```

Bảng trên là **kết quả thật** của ví dụ ở `reference/rules_vi.md` §E, không phải số minh hoạ.

> Bản mới còn 2 dòng chưa đạt ngưỡng (em dash 3,79 và nhịp câu 1,8) — **phải nói ra**, đừng chỉ khoe điểm tổng. Đoạn 3 câu thì nhịp câu vốn không đo được tử tế; đó là lý do script ghi chú "ít mẫu".

**Dải điểm:** `< 15` 🟢 tự nhiên · `15–34` 🟡 còn gợn · `35–59` 🟠 lộ rõ · `≥ 60` 🔴 đậm mùi AI.

---

## 6. Kho tài liệu của skill

| File | Nội dung |
|---|---|
| `reference/rules_vi.md` | 10 luật viết tiếng Việt tự nhiên + checklist chẩn đoán + ví dụ trước/sau |
| `reference/blacklist_vi.md` | Bảng cụm lộ mùi AI → bản thay thế, chia 8 nhóm |
| `scripts/ai_score.py` | Chấm điểm khách quan, so before/after, xuất JSON |
| `scripts/patterns_vi.json` | Dữ liệu pattern cho script — **sửa file này để cải tiến, không sửa code** |
| `scripts/selftest.py` | 22 ca kiểm chứng. **Đổi pattern hay trọng số thì PHẢI chạy lại** — `python3 scripts/selftest.py` |

**Cải tiến liên tục:** thấy Claude viết ra cụm nào nghe máy mà chưa có trong bảng → thêm vào `patterns_vi.json` + `reference/blacklist_vi.md`, bump version ở đây, ghi Changelog. Không cần đụng vào code Python. **Rồi chạy `python3 scripts/selftest.py` — FAIL thì đừng giao.**

---

## 7. Mở rộng sang ngôn ngữ khác (làm sau, khi TuanQG duyệt bản VI)

Khung đã tách sẵn: **quy trình 3 bước ở §4 không phụ thuộc ngôn ngữ**, chỉ có phần dữ liệu là riêng cho tiếng Việt.

Thêm một ngôn ngữ = thêm 3 file, không sửa gì ở SKILL.md ngoài một dòng bảng:

```
reference/rules_<lang>.md
reference/blacklist_<lang>.md
scripts/patterns_<lang>.json
```

Script nhận `--lang <code>` (mặc định `vi`) để nạp đúng bộ pattern.

Thứ tự đề xuất khi mở rộng: **EN** (dùng nhiều nhất sau VI — mail BD, prompt ChatGPT, bản gửi NCSOFT) → **KR** (làm việc với NCSOFT) → **TH/ID** (SEA). Mỗi ngôn ngữ cần một người bản ngữ duyệt bảng blacklist, vì "mùi AI" của mỗi tiếng khác nhau — tiếng Việt lộ ở từ Hán-Việt thừa và cặp tính từ song song, tiếng Anh lộ ở chỗ khác hẳn.

---

## 8. Quan hệ với skill khác

| Skill | Quan hệ |
|---|---|
| `content-crosscheck` | Chạy **sau** wording-vn. Skill này đổi chữ, cross-check xác nhận nghĩa không đổi so với nguồn gốc. |
| `translation-expert` | Chạy **trước**. Dịch xong → wording-vn gọt cho hết chất dịch máy. |
| `l2m-termbase-localization` | Có quyền cao hơn về term. Term đã chốt thì wording-vn không được đổi. |
| `layout-infographic` | Copy banner VN nên đi qua wording-vn trước khi giao designer. |

---

## Changelog

| Ngày | Version | Mô tả |
|------|---------|-------|
| 2026-08-28 | 1.1 | Cross-check độc lập bắt 4 lỗi **thiết kế** của v1.0: (a) trọng số blacklist 40 ⇒ trần điểm 60 ⇒ văn AI né được blacklist là **không bao giờ đỏ** (đo: AI viết khéo ra 9,5 🟢) → hạ về 30, trần lên 70; (b) chiết khấu văn <8 câu **thưởng cho AI** (cùng nội dung dán đôi: 9,5→19,0) → bỏ hẳn, chỉ còn ghi chú; (c) regex bullet chỉ bắt `**X**:` nên trượt đúng dạng `**X:**` doc mô tả → bắt cả hai; (d) 4 pattern **bắt oan** tiếng Việt bình thường ("tìm một cách khác", "vừa về tới nhà thì vừa lúc", "buổi lễ tiến hành trang trọng", "thư cần được gửi") + "Thứ hai tuần sau" bị tính là liên từ → siết lookahead, liên từ dễ nhầm phải có dấu phẩy. Vá 8 cụm doc có mà JSON thiếu. Thêm `selftest.py` 22 ca. |
| 2026-08-28 | 1.0 | Bản đầu — pilot tiếng Việt. SKILL.md + rules_vi + blacklist_vi (8 nhóm) + ai_score.py + patterns_vi.json. Trigger: gọi tên + tự bật ở output VN ≥80 từ hướng người đọc. |
