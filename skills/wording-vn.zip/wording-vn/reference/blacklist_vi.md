# blacklist_vi.md — Bảng cụm lộ mùi AI (Tiếng Việt) → bản thay thế

> Thuộc skill `wording-vn` v1.1 · Cập nhật 2026-08-28
> Đây là **từ điển tra**. Nguyên tắc nền nằm ở `rules_vi.md`.
> Dữ liệu máy đọc được: `../scripts/patterns_vi.json` — **sửa cả hai nơi khi thêm cụm mới.**

**Cách đọc bảng:** cột "Thay bằng" là gợi ý, không phải luật. Nhiều cụm cách chữa đúng nhất là **xoá hẳn**, ghi `(bỏ)`.

---

## Nhóm 1 — Rào đón mở bài

| Cụm lộ | Thay bằng |
|---|---|
| Điều quan trọng cần lưu ý là | (bỏ) — nói thẳng cái quan trọng đó |
| Cần lưu ý rằng / Xin lưu ý rằng | (bỏ) |
| Trong bối cảnh (hiện nay / hiện tại) | (bỏ), trừ khi bối cảnh là nội dung thật |
| Có thể nói rằng / Có thể thấy rằng | (bỏ) |
| Về cơ bản / Nhìn chung / Nói chung | (bỏ) |
| Trước hết, hãy cùng | (bỏ) |
| Hãy cùng khám phá / tìm hiểu / điểm qua | (bỏ) |
| Dưới đây là một số | Dưới đây là / (bỏ, đi thẳng vào danh sách) |
| Như chúng ta đã biết | (bỏ) |
| Trong thời đại ngày nay | (bỏ) |

## Nhóm 2 — Đuôi lễ tân

| Cụm lộ | Thay bằng |
|---|---|
| Hy vọng thông tin trên hữu ích | (bỏ) |
| Nếu cần thêm thông tin, đừng ngần ngại | (bỏ) hoặc "Cần gì thêm anh nhắn em." |
| Chúc bạn thành công / Chúc bạn một ngày tốt lành | (bỏ) |
| Tóm lại, có thể thấy rằng | (bỏ) — nếu cần chốt thì chốt bằng hành động |
| Trên đây là toàn bộ | (bỏ) |
| Rất mong nhận được phản hồi từ bạn | Anh xem giúp em nhé. |

## Nhóm 3 — Danh-từ-hoá (nặng nhất trong tiếng Việt)

| Cụm lộ | Thay bằng |
|---|---|
| việc + [động từ] | [động từ] trần — "việc triển khai" → "triển khai" |
| sự + [động từ] | "sự gia tăng của X" → "X tăng" |
| quá trình + [động từ] | thường bỏ được — "quá trình xử lý" → "xử lý" |
| công tác / hoạt động + [động từ] | [động từ] |
| tiến hành + [động từ] | [động từ] — "tiến hành rà soát" → "rà soát" |
| thực hiện việc + [động từ] | [động từ] |
| đưa ra quyết định | quyết định |
| có sự thay đổi | thay đổi |
| mang lại hiệu quả | hiệu quả / có tác dụng |
| đóng vai trò quan trọng trong | quan trọng với / quyết định |

## Nhóm 4 — Từ đệm rỗng

| Cụm lộ | Thay bằng |
|---|---|
| một cách [tính từ] | [tính từ] trần — "tăng một cách nhanh chóng" → "tăng nhanh" |
| vô cùng / hết sức / cực kỳ / rất đỗi | (bỏ) hoặc thay bằng số |
| thực sự / thật sự | (bỏ) |
| đáng kể / rõ rệt / nhất định | **thay bằng số thật**; không có số thì (bỏ) |
| khá là / tương đối | (bỏ) |
| có thể / có lẽ (khi đã chắc) | (bỏ) |
| trong số đó | (bỏ) |
| như đã đề cập ở trên | (bỏ) |
| nói một cách khác | tức là |
| chính vì vậy mà | nên |

## Nhóm 5 — Cặp song song & cấu trúc đối

| Cụm lộ | Thay bằng |
|---|---|
| nhanh chóng và hiệu quả | chọn một |
| rõ ràng và mạch lạc | rõ |
| đa dạng và phong phú | đa dạng |
| toàn diện và sâu sắc | kỹ |
| ổn định và bền vững | ổn định |
| chi tiết và cụ thể | cụ thể |
| an toàn và bảo mật | chọn một |
| không chỉ ... mà còn | tách hai câu, hoặc bỏ vế yếu |
| vừa ... vừa | tách |
| không những ... mà còn | tách |
| tuy ... nhưng (đầy đủ cả cặp) | bỏ "tuy", giữ "nhưng" |

## Nhóm 6 — Bị động dịch máy

| Cụm lộ | Thay bằng |
|---|---|
| được thực hiện bởi | do ... làm |
| được coi là / được xem là | là |
| được biết đến như là | là / gọi là |
| cần được xem xét | cần xem lại / anh xem giúp |
| đã được hoàn thành | xong |
| sẽ được cập nhật | sẽ cập nhật |
| bị ảnh hưởng bởi | do ... |

## Nhóm 7 — Liên từ mở đoạn (đếm mật độ, không cấm tuyệt đối)

`Bên cạnh đó` · `Hơn nữa` · `Ngoài ra` · `Đồng thời` · `Thêm vào đó` · `Mặt khác` · `Do đó` · `Vì vậy` · `Chính vì thế` · `Tuy nhiên` · `Đầu tiên/Thứ hai/Cuối cùng` (khi không phải danh sách thật)

→ Giữ **≤ 25%** số câu. Cách chữa nhanh nhất là xoá liên từ — quan hệ giữa hai câu thường đã tự rõ.

## Nhóm 8 — Sáo ngữ diễn giải

| Cụm lộ | Thay bằng |
|---|---|
| Điều này cho thấy | Nghĩa là / (bỏ, nói thẳng kết luận) |
| Điều này đồng nghĩa với việc | Tức là |
| Đây là một yếu tố quan trọng | (bỏ — câu không mang thông tin) |
| cần được quan tâm đúng mức | (bỏ) |
| đáp ứng nhu cầu ngày càng cao của | (bỏ) |
| nâng cao trải nghiệm người dùng | (bỏ nếu không nói rõ nâng cái gì) |
| tối ưu hóa (dùng chung chung) | nói rõ tối ưu cái gì, theo hướng nào |
| giải pháp toàn diện | (bỏ) |
| mang tính chiến lược | (bỏ hoặc nói rõ chiến lược nào) |
| với tư cách là | (bỏ) |

---

## Dấu câu & hình thức

| Dấu hiệu | Ngưỡng / cách chữa |
|---|---|
| Em dash `—` | Script đo **≤ 3 / 1000 ký tự** (đây mới là ngưỡng thật). Cảm tính: ≤ 1 lần / 300 từ. Thừa thì đổi sang dấu phẩy, dấu hai chấm, hoặc tách câu. |
| Emoji đầu bullet không có chức năng | Bỏ. Giữ emoji khi nó là **nhãn phân loại** (✅/⚠️/🔴 trong bảng trạng thái). |
| Bullet 3 mục, cùng độ dài, cùng cấu trúc `**X:** y` | Gộp thành văn xuôi, hoặc để độ dài lệch tự nhiên. |
| Bold rải khắp câu | Bold tối đa 1 cụm / đoạn. Bold mọi thứ = không bold gì. |
| Ngoặc đơn tiếng Anh cho từ ai cũng hiểu | "doanh thu (revenue)" → "doanh thu". Chỉ giữ ngoặc cho term lần đầu xuất hiện và thật sự cần. |

---

## Nhật ký bổ sung

> Thêm cụm mới thì ghi một dòng ở đây + thêm vào `patterns_vi.json` + bump version SKILL.md.

| Ngày | Cụm thêm | Bắt gặp ở đâu |
|---|---|---|
| 2026-08-28 | (bản đầu — 8 nhóm) | — |
| 2026-08-28 | v1.1 — vá 8 cụm bảng có mà script thiếu: `Nói chung` · `Về cơ bản` · `Nhìn chung` · `rất đỗi` · `nhất định sẽ` · `tuy…nhưng` · `tối ưu hóa` · `việc/sự + [động từ] bất kỳ` | Cross-check độc lập 28/08 |
| 2026-08-28 | v1.1 — siết 4 pattern **bắt oan**: `một cách`, `vừa…vừa`, `tiến hành`, `cần được` nay có lookahead loại trừ nghĩa thường | Cùng đợt |
