# rules_vi.md — 10 luật viết tiếng Việt tự nhiên

> Thuộc skill `wording-vn` v1.1 · Cập nhật 2026-08-28
> Đọc kèm `blacklist_vi.md` (bảng cụm cụ thể). File này là **nguyên tắc**, file kia là **từ điển tra**.

---

## A. Vì sao văn AI nghe ra là AI

Không phải vì nó sai. Nó lộ vì **quá đều**. Mọi câu dài bằng nhau, mọi đoạn mở bằng một liên từ, mọi ý gói thành đúng ba gạch đầu dòng, mọi tính từ đi thành cặp. Người viết thật thì lệch: có câu dài lê thê, có câu bốn chữ, có chỗ nói thẳng cụt lủn.

Dấu hiệu thứ hai: **rào đón**. Văn AI hay đặt một lớp đệm trước khi vào việc — "Điều quan trọng cần lưu ý là...", "Trong bối cảnh hiện tại...". Người Việt viết cho đồng nghiệp đọc thì vào thẳng.

Dấu hiệu thứ ba, riêng tiếng Việt: **Hán-Việt hoá và danh-từ-hoá**. "Tiến hành thực hiện việc rà soát" thay vì "rà soát". Câu nào cũng có "việc", "sự", "quá trình", "một cách".

Ba luật đầu dưới đây trị ba thứ đó.

---

## B. 10 luật

### Luật 1 — Vào thẳng việc

Bỏ mọi lớp đệm mở đầu. Câu đầu tiên phải mang thông tin.

| ❌ | ✅ |
|---|---|
| Điều quan trọng cần lưu ý là doanh thu tháng 7 đã giảm. | Doanh thu tháng 7 giảm 16,4%. |
| Trong bối cảnh thị trường hiện nay, chúng ta cần xem xét lại chiến lược giá. | Giá đang lệch thị trường, nên xem lại. |
| Dưới đây là một số điểm chính cần lưu ý: | (bỏ hẳn — đi thẳng vào các điểm) |

### Luật 2 — Động từ thay cụm danh từ

Thấy "việc / sự / quá trình / công tác / hoạt động + động từ" → đổi về động từ trần.

| ❌ | ✅ |
|---|---|
| Việc triển khai event đã được thực hiện vào ngày 15/07. | Event chạy từ 15/07. |
| Quá trình gia tăng của số lượng người chơi | Số người chơi tăng |
| Tiến hành rà soát lại toàn bộ danh sách | Rà lại cả danh sách |
| Sự sụt giảm này cho thấy... | Sụt như vậy nghĩa là... |

### Luật 3 — Cắt từ đệm rỗng

Đọc lại, bỏ thử từng từ. Bỏ mà nghĩa không đổi thì bỏ luôn.

Nhóm hay thừa nhất: `một cách` · `vô cùng` · `hết sức` · `cực kỳ` · `thực sự` · `nhất định` · `đáng kể` · `nói chung` · `có thể nói` · `về cơ bản` · `trong số đó`.

> "Event này vô cùng hiệu quả và đã mang lại doanh thu tăng một cách đáng kể"
> → "Event này hiệu quả, doanh thu tăng 23%."

Lưu ý: khi cắt "đáng kể" thì phải **thay bằng số thật**, không phải xoá trống. Nếu không có số thì giữ nguyên mức mơ hồ nhưng chọn từ gọn hơn.

### Luật 4 — Nhịp câu phải lệch

Không để câu nào cũng 25–30 từ. Xen câu ngắn. Một câu bốn chữ đặt đúng chỗ có sức nặng hơn ba câu giải thích.

> ❌ Doanh thu tháng 7 đạt 1,31 triệu USD, giảm 16,4% so với tháng trước, đây là tháng giảm thứ hai liên tiếp và nguyên nhân chính đến từ việc DAU sụt 27,2% sau ngày 15/07.
>
> ✅ Doanh thu tháng 7 đạt 1,31 triệu USD, giảm 16,4% so với tháng 6. Tháng giảm thứ hai liên tiếp. Gốc rễ nằm ở DAU: sụt 27,2% ngay sau 15/07.

Ngưỡng tham khảo: độ dài câu trung bình **11–22 từ**, độ lệch chuẩn **≥ 7**. (Đơn vị "từ" ở đây là âm tiết cách nhau bởi khoảng trắng — tiếng Việt đếm ra số lớn hơn tiếng Anh cùng nội dung.)

### Luật 5 — Bỏ cặp song song

Tiếng Việt AI rất hay ghép hai từ gần nghĩa cho "đầy đặn": *nhanh chóng và hiệu quả*, *rõ ràng và mạch lạc*, *đa dạng và phong phú*, *toàn diện và sâu sắc*, *ổn định và bền vững*.

Chọn **một** từ. Từ nào đúng hơn thì giữ, bỏ từ kia.

Cùng họ với nó là cấu trúc `không chỉ... mà còn` và `vừa... vừa`. Tách thành hai câu, hoặc bỏ vế yếu.

### Luật 6 — Câu chủ động, chủ ngữ rõ

| ❌ | ✅ |
|---|---|
| Báo cáo đã được hoàn thành bởi team Analytics. | Team Analytics làm xong báo cáo. |
| Vấn đề này cần được xem xét. | Cần xem lại chỗ này. / Anh xem lại giúp chỗ này. |
| Nó được coi là nguyên nhân chính. | Đây là nguyên nhân chính. |

Bị động chỉ giữ khi **thật sự không biết ai làm** hoặc khi người làm không quan trọng.

### Luật 7 — Đừng mở mọi đoạn bằng liên từ

`Bên cạnh đó` · `Hơn nữa` · `Ngoài ra` · `Đồng thời` · `Tuy nhiên` · `Do đó` · `Vì vậy` — mỗi bài dùng vài lần là đủ. Nếu đoạn nào cũng mở bằng một trong số đó thì bài đọc như danh sách đánh số bị giấu đi.

Ngưỡng: **≤ 25%** số câu mở đầu bằng liên từ chuyển tiếp.

Cách chữa: bỏ hẳn liên từ. Quan hệ giữa hai ý thường đã tự rõ, không cần biển chỉ đường.

### Luật 8 — Bullet không cần đều tăm tắp

Ba gạch đầu dòng, mỗi gạch một câu, mỗi câu cùng cấu trúc `**Tiêu đề:** giải thích` — đó là chữ ký của AI.

Chữa: gộp ý gần nhau thành văn xuôi, giữ bullet cho thứ **thật sự là danh sách** (các bước, các món, các ngày). Danh sách thật thì để độ dài các mục lệch nhau tự nhiên, không ép cho bằng.

### Luật 9 — Bỏ đuôi lễ tân

Cuối bài không cần: *"Hy vọng thông tin trên hữu ích"* · *"Nếu cần thêm thông tin, đừng ngần ngại liên hệ"* · *"Chúc bạn thành công"* · *"Tóm lại, có thể thấy rằng..."*.

Bài kết thúc ở ý cuối cùng. Nếu cần một dòng chốt thì dòng đó phải mang **hành động hoặc kết luận mới**, không phải lời chào.

### Luật 10 — Viết cho người cụ thể

Trước khi gọt, hỏi: *ai đọc?* Cùng một nội dung, ba giọng khác nhau:

| Người đọc | Giọng |
|---|---|
| Người chơi (thông báo event) | Gần, nói thẳng lợi ích, câu ngắn, xưng hô đúng cộng đồng game |
| Sếp / NCSOFT (report) | Số trước, nhận định sau, không hoa mỹ, không cảm thán |
| Team nội bộ (mail, chat) | Như nói chuyện, được phép cụt, được phép dùng từ nghề |
| Đối tác BD | Lịch sự nhưng không khúm núm, mỗi câu một mục đích |

Không có giọng "chung chung an toàn". Giọng chung chung chính là giọng AI.

---

## C. Checklist chẩn đoán (những gì script không đo được)

Script đếm được cụm từ và nhịp câu. Bốn thứ dưới đây phải tự đọc:

1. **Thông tin có bị chôn ở cuối đoạn không?** Câu quan trọng nhất nên đứng đầu hoặc đứng cuối, đừng kẹt giữa.
2. **Có câu nào nói mà không nói gì không?** Kiểu "Đây là một yếu tố quan trọng cần được quan tâm đúng mức." Xoá.
3. **Xưng hô có nhất quán không?** Đang "anh/em" giữa bài nhảy sang "bạn" là dấu hiệu ghép máy.
4. **Đọc to lên có vấp không?** Chỗ nào phải đọc lại lần hai thì chỗ đó cần viết lại, dù điểm số có đẹp.

---

## D. Những chỗ KHÔNG được gọt

- **Số, ngày, tên riêng, đơn vị** — copy y nguyên (SKILL.md §3 luật 1)
- **Term game đã chốt trong glossary** — muốn đổi phải qua `l2m-termbase-localization`
- **Câu trích dẫn nguyên văn** từ NCSOFT, hợp đồng, patch note chính thức
- **Cảnh báo an toàn / điều khoản pháp lý** — dài dòng ở đây là cố ý
- **Tên file, path, lệnh, code**

---

## E. Ví dụ đầy đủ một lần gọt

**Bản gốc (do Claude viết — đo được 47,3/100 🟠):**

> Trong bối cảnh thị trường game mobile ngày càng cạnh tranh, việc theo dõi và phân tích các chỉ số vận hành trở nên vô cùng quan trọng. Báo cáo tháng 7 đã được hoàn thành bởi team Analytics, cho thấy một số điểm đáng chú ý. Bên cạnh đó, doanh thu đã ghi nhận sự sụt giảm đáng kể so với tháng trước. Hơn nữa, số lượng người chơi hoạt động hàng ngày cũng đã giảm một cách rõ rệt sau ngày 15/07. Điều này cho thấy chúng ta cần tiến hành xem xét lại chiến lược vận hành một cách toàn diện và sâu sắc. Hy vọng những thông tin trên sẽ hữu ích cho anh.

**Bản viết lại (đo được 22,7/100 🟡 — giảm 24,6 điểm, ngắn hơn 57% chữ):**

> Báo cáo tháng 7 của team Analytics có hai điểm cần lưu ý.
>
> Doanh thu đạt 1,31 triệu USD, giảm 16,4% so với tháng 6 — tháng giảm thứ hai liên tiếp. DAU cũng sụt 27,2% ngay sau 15/07, và đây nhiều khả năng là gốc rễ.
>
> Chiến lược vận hành nên xem lại từ mốc 15/07 đó.

Đối chiếu ý: 4 ý gốc (báo cáo T7 do Analytics làm · doanh thu giảm · DAU giảm sau 15/07 · cần xem lại chiến lược) → 4/4 còn. Lớp rào đón mở bài, câu "thị trường cạnh tranh" và lời chào cuối bị bỏ vì **không mang thông tin** — đây là bỏ chữ, không phải bỏ ý.

⚠️ Bản mới vẫn 🟡 chứ không 🟢 — vì đoạn chỉ có 3 câu nên nhịp câu đo ra rất đều (1,8), và có 1 em dash trên đoạn ngắn. Đó là **giới hạn của phép đo trên văn ngắn**, không phải bản viết lại dở. Điểm là cái phanh, không phải mục tiêu.

⚠️ Số `1,31 triệu USD`, `16,4%`, `27,2%` trong ví dụ là số thật lấy từ bản gốc dài hơn. Khi gọt thật mà bản gốc **không có số**, tuyệt đối không được bịa số vào cho câu văn mạnh hơn.
