# Wording VN — Viết lại cho tự nhiên, hết mùi AI — Cách dùng

Nhận một đoạn văn tiếng Việt do AI viết và gọt lại cho tự nhiên, cô đọng, giữ nguyên 100% nội dung. Có script chấm điểm 'mùi AI' 0-100 để đo trước/sau, không nói cảm tính. Kèm 10 luật viết + bảng 8 nhóm cụm từ lộ AI và bản thay thế. Kèm 22 ca kiểm chứng để mỗi lần chỉnh pattern là biết ngay có làm hỏng chỗ khác không. Pilot tiếng Việt, khung đã chừa chỗ cắm thêm ngôn ngữ khác.

Skill tự chứa script chấm điểm — cài xong dùng được ngay, không cần kết nối workspace.

## Cách A — Cài để dùng nhiều lần (khuyến nghị)
1. Mở Claude.ai → Settings > Capabilities (hoặc Customize > Skills).
2. Bấm Upload → chọn file wording-vn.zip vừa tải về.
3. Xong. Dán đoạn văn rồi nói 'wording lại giúp mình' hoặc 'bỏ mùi AI đoạn này'.

## Cách B — Dùng nhanh (Cowork / nơi có code tool)
1. Giải nén gói, GIỮ NGUYÊN thư mục scripts/ và reference/.
2. Chấm điểm: python3 scripts/ai_score.py --file bai.md
3. So trước/sau: python3 scripts/ai_score.py --before goc.md --after moi.md

## Ghi chú
- Điểm THẤP = tự nhiên. Điểm chỉ là cái phanh, không phải mục tiêu — văn 5 điểm mà đọc trúc trắc thì vẫn hỏng.
- Skill KHÔNG đổi số liệu, tên riêng, thuật ngữ. Đổi cách nói, không đổi điều được nói.
- Cải tiến bằng cách sửa scripts/patterns_vi.json + reference/blacklist_vi.md, không cần sửa code.
