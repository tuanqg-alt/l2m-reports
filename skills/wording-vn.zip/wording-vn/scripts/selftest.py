#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest.py — chấm lại chính bộ chấm điểm.  (skill wording-vn v1.1)

    python3 selftest.py            # chạy tất cả, in bảng
    python3 selftest.py -q         # chỉ in dòng kết luận

VÌ SAO CÓ FILE NÀY
------------------
Bản v1.0 tự khen: nó báo "điểm giảm 62 → 8,9, tốt hơn 53 điểm" trong khi cùng lúc
(a) cho văn AI viết khéo — né sạch blacklist, câu đều 25 từ — **9,5 🟢 TỰ NHIÊN**,
(b) bắt oan hàng loạt câu tiếng Việt bình thường ("tìm một cách khác", "vừa về tới
nhà thì vừa lúc anh gọi", "Thứ hai tuần sau mình họp"),
(c) thưởng điểm cho văn ngắn nên AI viết ít câu dài lại được lợi.
Không có ca kiểm chứng nào bắt được cả ba — vì bộ test khi đó chỉ có đúng cái ca mà
tác giả đã biết là sẽ đậu.

Luật rút ra: **thêm pattern hay đổi trọng số thì PHẢI chạy lại file này.**
Ca nào FAIL nghĩa là bản sửa vừa rồi làm hỏng chỗ khác, đừng giao.

Thêm ca mới: nhét vào CASES bên dưới. Ca tốt = ca mà bạn KHÔNG chắc nó sẽ đậu.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ai_score as m  # noqa: E402

# ---------------------------------------------------------------- văn bản mẫu
HUMAN = """Anh Tommy, em gửi anh số tháng 7.

Doanh thu 1,31 triệu USD. Giảm 16,4%. Tháng thứ hai đi xuống.

Chỗ đáng lo không phải doanh thu mà là DAU — sau 15/07 nó rơi 27,2% và tới giờ chưa
hồi. Em dò lại lịch event thì đúng mốc đó mình kết thúc chuỗi login reward mà không
có gì bù vào.

Đề xuất: dựng một chuỗi retention ngắn cho nửa đầu tháng 9, chi phí thấp thôi. Mục
tiêu kéo DAU về vùng 150K rồi tính tiếp.

Anh xem giúp em nhé."""

AI_THO = """Trong bối cảnh thị trường game mobile ngày càng cạnh tranh, việc theo dõi
và phân tích các chỉ số vận hành trở nên vô cùng quan trọng. Báo cáo tháng 7 đã được
hoàn thành bởi team Analytics, cho thấy một số điểm đáng chú ý. Bên cạnh đó, doanh
thu đã ghi nhận sự sụt giảm đáng kể so với tháng trước. Hơn nữa, số lượng người chơi
hoạt động hàng ngày cũng đã giảm một cách rõ rệt sau ngày 15/07. Điều này cho thấy
chúng ta cần tiến hành xem xét lại chiến lược vận hành một cách toàn diện và sâu sắc.
Hy vọng những thông tin trên sẽ hữu ích cho anh."""

# Ca KHO nhat: AI viet kheo, ne sach blacklist, nhung cau nao cung 25 tu deu tam tap.
AI_KHEO = """Báo cáo tháng 7 ghi nhận doanh thu đạt mức 1,31 triệu USD trên toàn bộ hệ
thống máy chủ đang vận hành tại thị trường Việt Nam.
So với kỳ trước, con số này phản ánh xu hướng đi xuống kéo dài sang tháng thứ hai
liên tiếp của chỉ số tài chính toàn hệ thống.
Chỉ số người dùng hoạt động hàng ngày cũng ghi nhận mức suy giảm sau mốc thời gian
ngày mười lăm tháng bảy vừa qua trên toàn bộ máy chủ.
Nguyên nhân được xác định xuất phát từ thời điểm kết thúc chuỗi phần thưởng đăng nhập
mà chưa có phương án thay thế nào được chuẩn bị trước.
Nhóm vận hành khuyến nghị xây dựng chuỗi hoạt động giữ chân người chơi trong nửa đầu
tháng chín với ngân sách hạn chế và thời gian triển khai ngắn."""

# Cau tieng Viet BINH THUONG — khong duoc dinh mot cum blacklist nao.
KHONG_DUOC_BAT = [
    "Anh thử tìm một cách khác xem sao, cách này không ổn lắm đâu.",
    "Em vừa về tới nhà thì vừa lúc anh gọi, tiếc quá.",
    "Buổi lễ tiến hành trang trọng tại sảnh lớn của khách sạn.",
    "Thư này cần được gửi trước 5 giờ chiều nay nhé anh.",
    "Thứ hai tuần sau mình họp, anh nhớ giữ lịch giúp em.",
    "Cuối cùng của danh sách là mục chi phí sản xuất video.",
    "Không còn một cách nào khác đâu anh, phải làm lại từ đầu.",
]

# Cum PHAI bat duoc — doc blacklist_vi.md co ghi thi script phai thay.
PHAI_BAT = [
    "Nói chung, doanh thu vẫn tăng đều qua các tháng gần đây.",
    "Về cơ bản đây là bản cuối cùng rồi, không sửa nữa.",
    "Cần tối ưu hóa lại toàn bộ hệ thống vận hành hiện tại.",
    "Tuy trời mưa nhưng event ngoài trời vẫn chạy đúng lịch.",
    "Điều quan trọng cần lưu ý là chi phí đang vượt ngân sách.",
    "Doanh thu đã được cải thiện một cách đáng kể trong quý này.",
]

BULLET_AI = """Tổng hợp kết quả tháng 7 của toàn bộ hệ thống như sau đây.

- **Doanh thu:** giảm so với tháng trước một cách đáng kể
- **Người chơi:** sụt giảm rõ rệt sau ngày 15 tháng 7
- **Chiến lược:** cần được xem xét lại một cách toàn diện
- **Ngân sách:** cần được cân nhắc lại cho phù hợp hơn"""


# -------------------------------------------------------------------- các ca
def score(t: str, cfg) -> float:
    r = m.analyse(t, cfg)
    return r["score"] if r["score"] is not None else -1.0


def CASES(cfg):
    h, a_tho, a_kheo = score(HUMAN, cfg), score(AI_THO, cfg), score(AI_KHEO, cfg)

    yield ("Văn người thật phải 🟢 (< 15)", h < 15, f"đo được {h}")
    yield ("Văn AI thô phải 🟠/🔴 (≥ 35)", a_tho >= 35, f"đo được {a_tho}")
    yield ("Văn AI viết khéo KHÔNG được 🟢 (≥ 15)", a_kheo >= 15,
           f"đo được {a_kheo} — đây là ca v1.0 trượt: né blacklist là auto 🟢")
    yield ("Người phải thấp hơn AI thô rõ rệt (cách ≥ 20)", a_tho - h >= 20,
           f"{h} vs {a_tho}, cách {a_tho - h:.1f}")
    yield ("Người phải thấp hơn AI khéo", h < a_kheo, f"{h} vs {a_kheo}")

    # v1.0: dan doi noi dung lam diem TOT hon (do chiet khau van ngan)
    d = score(AI_KHEO + "\n\n" + AI_KHEO, cfg)
    yield ("Dán đôi cùng nội dung không được đổi điểm quá 3", abs(d - a_kheo) <= 3.0,
           f"{a_kheo} -> {d} (lệch {d - a_kheo:+.1f})")

    for s in KHONG_DUOC_BAT:
        hits = [p for g in cfg["groups"] for p, rx in g["_compiled"] if rx.search(s)]
        tr = any(m.fold(s.strip()).startswith(m.fold(o)) for o in cfg["transition_openers"])
        yield (f"Không bắt oan: {s[:38]}…", not hits and not tr,
               f"blacklist={hits} lientu={tr}")

    for s in PHAI_BAT:
        hits = [p for g in cfg["groups"] for p, rx in g["_compiled"] if rx.search(s)]
        yield (f"Phải bắt được: {s[:38]}…", bool(hits), f"hits={len(hits)}")

    r = m.analyse(BULLET_AI, cfg)
    yield ("Bullet `**Nhãn:** …` phải bị tính là đều tăm tắp",
           r["metrics"]["bullet_uniformity"] > 0.4,
           f"uniformity={r['metrics']['bullet_uniformity']}")

    yield ("Đoạn quá ngắn phải từ chối chấm, không bịa điểm",
           m.analyse("Doanh thu giảm.", cfg).get("too_short") is True, "")

    yield ("Trần điểm khi 0 hit blacklist phải ≥ 70 (nếu không, né blacklist = miễn nhiễm 🔴)",
           (sum(cfg["weights"].values()) - cfg["weights"]["blacklist"]) >= 70,
           f"trần = {sum(cfg['weights'].values()) - cfg['weights']['blacklist']}")


def main() -> int:
    quiet = "-q" in sys.argv
    cfg = m.load_patterns("vi")
    rows = list(CASES(cfg))
    fails = [(n, d) for n, ok, d in rows if not ok]
    if not quiet:
        for name, ok, detail in rows:
            print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"   [{detail}]" if detail else ""))
        print()
    print(f"{'✅' if not fails else '🔴'} SELFTEST: {len(rows) - len(fails)}/{len(rows)} PASS"
          + (f" · {len(fails)} FAIL" if fails else ""))
    for n, d in fails:
        print(f"   FAIL: {n}  [{d}]")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
