#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ai_score.py — Chấm điểm "mùi AI" của một đoạn văn.  (skill wording-vn v1.1)

Điểm 0-100, THẤP = tự nhiên. Điểm chỉ là cái phanh, không phải mục tiêu:
văn 5 điểm mà đọc lên trúc trắc thì vẫn hỏng. Người quyết cuối cùng là người đọc.

Cách dùng
---------
  python3 ai_score.py --file bai.md
  cat bai.md | python3 ai_score.py
  python3 ai_score.py --before goc.md --after moi.md      # bảng so sánh
  python3 ai_score.py --file bai.md --json                # máy đọc
  python3 ai_score.py --file bai.md --lang vi             # mặc định vi

Dữ liệu pattern nằm ở patterns_<lang>.json cùng thư mục — sửa JSON để cải
tiến, KHÔNG cần đụng vào file này. Thêm ngôn ngữ = thêm 1 file patterns_<lang>.json.

$0 runtime — thuần chuẩn thư viện Python, không gọi API, không cần mạng.
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent

# Python `re` không hiểu \p{L}. [^\W\d_] với cờ UNICODE cho kết quả tương đương.
PL = r"[^\W\d_]"

# Câu kết thúc bằng . ! ? … hoặc xuống dòng trống.
SENT_SPLIT = re.compile(r"(?<=[.!?…])\s+|\n{2,}")
BULLET_RE = re.compile(r"^\s*(?:[-*+•]|\d+[.)])\s+(.*)$")
CODE_FENCE = re.compile(r"```.*?```", re.S)
INLINE_CODE = re.compile(r"`[^`\n]+`")
MD_TABLE_ROW = re.compile(r"^\s*\|.*\|\s*$")
URL_RE = re.compile(r"https?://\S+")


# ---------------------------------------------------------------- nạp cấu hình
def load_patterns(lang: str) -> dict:
    path = HERE / f"patterns_{lang}.json"
    if not path.exists():
        available = sorted(p.stem.replace("patterns_", "") for p in HERE.glob("patterns_*.json"))
        sys.exit(
            f"[LỖI] Chưa có bộ pattern cho ngôn ngữ '{lang}' ({path.name}).\n"
            f"       Hiện có: {', '.join(available) or '(không có file nào)'}"
        )
    cfg = json.loads(path.read_text(encoding="utf-8"))
    for group in cfg.get("groups", []):
        group["_compiled"] = [
            (raw, re.compile(raw.replace(r"\p{L}", PL), re.IGNORECASE | re.UNICODE))
            for raw in group.get("patterns", [])
        ]
    return cfg


# ------------------------------------------------------------------ chuẩn hoá
def strip_noise(text: str) -> str:
    """Bỏ code block, bảng markdown, URL — những chỗ KHÔNG được tính là văn xuôi."""
    text = CODE_FENCE.sub(" ", text)
    text = INLINE_CODE.sub(" ", text)
    text = URL_RE.sub(" ", text)
    kept = [ln for ln in text.splitlines() if not MD_TABLE_ROW.match(ln)]
    return "\n".join(kept)


def prose_only(text: str) -> str:
    """Bỏ luôn cả markup nhấn mạnh + heading để đếm từ cho sạch."""
    text = re.sub(r"^#{1,6}\s*", "", text, flags=re.M)
    text = re.sub(r"[*_]{1,3}", "", text)
    return text


def word_count(text: str) -> int:
    return len(re.findall(rf"{PL}+", text, re.UNICODE))


def split_sentences(text: str) -> list[str]:
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        body = BULLET_RE.match(line)
        line = body.group(1) if body else line
        for s in SENT_SPLIT.split(line):
            s = s.strip()
            if word_count(s) >= 3:
                out.append(s)
    return out


def first_words(sentence: str, n: int = 4) -> str:
    toks = re.findall(rf"{PL}+", sentence, re.UNICODE)
    return " ".join(toks[:n]).lower()


def fold(s: str) -> str:
    """Bỏ dấu — chỉ dùng để so khớp mở đầu câu cho khoan dung."""
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if not unicodedata.combining(c))


# --------------------------------------------------------------- các chỉ báo
def lerp_score(value: float, good: float, bad: float) -> float:
    """0 điểm ở mức 'good', 100 điểm ở mức 'bad', kẹp trong [0,100]."""
    if bad == good:
        return 0.0
    raw = (value - good) / (bad - good) * 100.0
    return max(0.0, min(100.0, raw))


def analyse(text: str, cfg: dict) -> dict:
    clean = prose_only(strip_noise(text))
    words = word_count(clean)
    sentences = split_sentences(clean)
    th = cfg["thresholds"]

    # Bo pattern la cua TIENG VIET. Van tieng Anh (hay tieng khac) khong dinh cum nao
    # => ra diem thap => bao "TU NHIEN" mot cach sai lam. Do that 28/08/2026: mot doan
    # AI tieng Anh kinh dien ("It is important to note... Furthermore... In conclusion,
    # I hope this information is useful") cham ra 7,0/100 🟢.
    # Nhan dien tho: tieng Viet dung dau thanh/dau mu day dac.
    letters = [c for c in clean if c.isalpha()]
    vn_marks = sum(1 for c in unicodedata.normalize("NFD", clean) if unicodedata.combining(c))
    wrong_lang = bool(letters) and (vn_marks / len(letters)) < 0.08

    # Dưới 20 từ văn xuôi thì mọi tỉ lệ đều vô nghĩa — báo thẳng, đừng bịa ra điểm.
    if words < 20:
        return {
            "score": None,
            "words": words,
            "sentences": len(sentences),
            "too_short": True,
            "metrics": {}, "sub_scores": {}, "by_group": {}, "hits": [],
        }

    # --- 1. cụm blacklist -------------------------------------------------
    hits, by_group = [], {}
    for group in cfg["groups"]:
        n = 0
        for raw, rx in group["_compiled"]:
            for m in rx.finditer(clean):
                n += 1
                line_no = clean[: m.start()].count("\n") + 1
                hits.append(
                    {
                        "group": group["id"],
                        "group_label": group["label"],
                        "weight": group.get("weight", 1.0),
                        "match": m.group(0).strip(),
                        "line": line_no,
                        "pattern": raw,
                    }
                )
        by_group[group["id"]] = {"label": group["label"], "count": n}

    # Chuẩn hoá theo trọng số trung bình để con số đọc ra vẫn xấp xỉ "số cụm /100 từ",
    # nhóm nặng (rào đón, sáo ngữ) vẫn tính đậm hơn nhóm nhẹ.
    all_w = [g.get("weight", 1.0) for g in cfg["groups"]] or [1.0]
    norm = statistics.mean(all_w)
    weighted = sum(h["weight"] for h in hits) / norm
    bl_density = (weighted / words * 100) if words else 0.0

    # --- 2. độ dài & nhịp câu --------------------------------------------
    lens = [word_count(s) for s in sentences]
    avg_len = statistics.mean(lens) if lens else 0.0
    stdev = statistics.pstdev(lens) if len(lens) > 1 else 0.0

    # --- 3. liên từ mở câu ------------------------------------------------
    # So voi DAU CAU CON NGUYEN DAU PHAY — khong dung first_words() (no vut dau cau).
    # Ly do: cum de nham voi tu thuong ("thu hai", "cuoi cung", "dau tien") duoc khai
    # kem dau phay trong patterns_vi.json; bo dau phay di thi "Thu hai tuan sau minh
    # hop nhe" bi tinh la lien tu mo doan (do that 28/08/2026).
    openers = [fold(o) for o in cfg.get("transition_openers", [])]
    n_trans = sum(1 for s in sentences if any(fold(s.strip()).startswith(o) for o in openers))
    trans_ratio = (n_trans / len(sentences)) if sentences else 0.0

    # --- 4. em dash -------------------------------------------------------
    chars = max(len(clean), 1)
    emdash = (clean.count("—") + clean.count("–")) / chars * 1000

    # --- 5. bullet đều tăm tắp -------------------------------------------
    bullets = [BULLET_RE.match(ln).group(1).strip() for ln in strip_noise(text).splitlines() if BULLET_RE.match(ln)]
    uniformity = 0.0
    if len(bullets) >= 3:
        blens = [word_count(b) for b in bullets]
        spread = statistics.pstdev(blens) / (statistics.mean(blens) or 1)
        # Bat CA HAI dang: `**Nhan:** noi dung` (dau : trong bold) va `**Nhan**: noi dung`.
        # Ban dau chi bat dang thu hai => dang PHO BIEN nhat, cung la dang blacklist_vi.md
        # mo ta, khong bao gio bi bat (do that 28/08/2026).
        bolded = sum(1 for b in bullets if re.match(r"^\*\*[^*]+\*\*\s*[:：-]|^\*\*[^*]+[:：]\*\*", b)) / len(bullets)
        uniformity = max(0.0, min(1.0, (1 - min(spread / 0.6, 1.0)) * 0.6 + bolded * 0.4))

    # --- chấm điểm --------------------------------------------------------
    t = th["avg_sentence_words"]
    if avg_len <= t["hi_good"]:
        len_score = 0.0 if avg_len >= t["lo_good"] else lerp_score(t["lo_good"] - avg_len, 0, t["lo_good"])
    else:
        len_score = lerp_score(avg_len, t["hi_good"], t["hi_bad"])

    parts = {
        "blacklist": lerp_score(bl_density, th["blacklist_per_100w"]["good"], th["blacklist_per_100w"]["bad"]),
        "sentence_length": len_score,
        "sentence_rhythm": lerp_score(stdev, th["sentence_stdev"]["good"], th["sentence_stdev"]["bad"]),
        "transition": lerp_score(trans_ratio, th["transition_ratio"]["good"], th["transition_ratio"]["bad"]),
        "emdash": lerp_score(emdash, th["emdash_per_1000c"]["good"], th["emdash_per_1000c"]["bad"]),
        "bullet": lerp_score(uniformity, th["bullet_uniformity"]["good"], th["bullet_uniformity"]["bad"]),
    }
    # ⚠️ KHONG ha trong so cho van ban ngan nua (bo 28/08/2026).
    # Ban v1.0 ha trong so do dai + nhip cau khi < 8 cau, tuong la "cong bang voi it
    # mau". Do thuc te: no THUONG cho van AI — AI hay viet it cau nhung cau dai deu
    # tam tap, roi duoc giam nhe dung 2 chi bao dang to cao no. Cung mot doan AI, dan
    # 2 lan cho du 8 cau thi diem xau di 9,5 -> 19,0. Nay chi GHI CHU it mau, khong
    # dong vao diem — de nguoi doc tu tru hao, may khong tu bao chua.
    w = dict(cfg["weights"])
    small_sample = len(sentences) < 8
    if len(bullets) < 3:
        w["bullet"] = 0.0
    total_w = sum(w.values()) or 1.0
    score = sum(parts[k] * w[k] for k in parts) / total_w

    return {
        "score": round(score, 1),
        "words": words,
        "sentences": len(sentences),
        "small_sample": small_sample,
        "metrics": {
            "blacklist_per_100w": round(bl_density, 2),
            "avg_sentence_words": round(avg_len, 1),
            "sentence_stdev": round(stdev, 1),
            "transition_ratio": round(trans_ratio, 3),
            "emdash_per_1000c": round(emdash, 2),
            "bullet_uniformity": round(uniformity, 2),
        },
        "wrong_lang": wrong_lang,
        "sub_scores": {k: round(v, 1) for k, v in parts.items()},
        "by_group": by_group,
        "hits": hits,
    }


# ------------------------------------------------------------------- in ra
BAND = [(15, "🟢 TỰ NHIÊN"), (35, "🟡 CÒN GỢN"), (60, "🟠 LỘ RÕ"), (101, "🔴 ĐẬM MÙI AI")]


def band(score: float) -> str:
    return next(label for cut, label in BAND if score < cut)


def fmt_report(r: dict, cfg: dict, title: str = "") -> str:
    if r.get("too_short"):
        return (f"{title}\n" if title else "") + (
            f"⚠️ KHÔNG CHẤM ĐƯỢC — chỉ có {r['words']} từ văn xuôi (cần ≥ 20).\n"
            "   Đoạn quá ngắn thì mọi tỉ lệ đều vô nghĩa. Đọc bằng mắt theo "
            "reference/rules_vi.md, đừng dựa vào điểm."
        )
    th = cfg["thresholds"]
    L = []
    head = f"📊 ĐIỂM MÙI AI: {r['score']}/100   {band(r['score'])}"
    L.append(f"{title}\n{head}" if title else head)
    L.append(f"   ({r['words']} từ · {r['sentences']} câu — điểm thấp = tự nhiên)")
    if r.get("wrong_lang"):
        L.append("   🔴 ĐOẠN NÀY CÓ VẺ KHÔNG PHẢI TIẾNG VIỆT — bộ pattern là của tiếng Việt,")
        L.append("      nên điểm dưới đây VÔ NGHĨA (văn AI tiếng Anh vẫn ra 🟢). Chưa hỗ trợ, xem SKILL.md §7.")
    if r.get("small_sample"):
        L.append("   ⓘ Dưới 8 câu — độ dài & nhịp câu ít mẫu, đọc con số đó dè chừng. "
                 "Điểm KHÔNG được giảm nhẹ vì lý do này.")
    L.append("")
    L.append(f"{'Chỉ báo':<26}{'Đo được':>10}{'Ngưỡng tốt':>16}")
    L.append("-" * 52)
    m = r["metrics"]
    rows = [
        ("Cụm blacklist /100 từ", m["blacklist_per_100w"], f"≤ {th['blacklist_per_100w']['good']}"),
        ("Độ dài câu TB (từ)", m["avg_sentence_words"],
         f"{th['avg_sentence_words']['lo_good']}–{th['avg_sentence_words']['hi_good']}"),
        ("Độ lệch nhịp câu", m["sentence_stdev"], f"≥ {th['sentence_stdev']['good']}"),
        ("Câu mở bằng liên từ", f"{m['transition_ratio']*100:.0f}%",
         f"≤ {th['transition_ratio']['good']*100:.0f}%"),
        ("Em dash /1000 ký tự", m["emdash_per_1000c"], f"≤ {th['emdash_per_1000c']['good']}"),
        ("Bullet đều tăm tắp", m["bullet_uniformity"], f"≤ {th['bullet_uniformity']['good']}"),
    ]
    for name, val, good in rows:
        L.append(f"{name:<26}{str(val):>10}{good:>16}")

    flagged = [(g["label"], g["count"]) for g in r["by_group"].values() if g["count"]]
    if flagged:
        L.append("")
        L.append("🔍 CỤM BỊ BẮT theo nhóm: " + " · ".join(f"{lbl} ({n})" for lbl, n in flagged))
        shown = r["hits"][:20]
        for h in shown:
            L.append(f"   dòng {h['line']:>3} │ [{h['group_label']}] \"{h['match']}\"")
        if len(r["hits"]) > len(shown):
            L.append(f"   ... còn {len(r['hits']) - len(shown)} cụm nữa")
    else:
        L.append("")
        L.append("🔍 CỤM BỊ BẮT: không có")
    return "\n".join(L)


def fmt_compare(b: dict, a: dict, cfg: dict) -> str:
    if b.get("too_short") or a.get("too_short"):
        which = "bản gốc" if b.get("too_short") else "bản viết lại"
        return (f"⚠️ KHÔNG SO SÁNH ĐƯỢC — {which} dưới 20 từ văn xuôi.\n"
                "   Đọc bằng mắt theo reference/rules_vi.md.")
    th = cfg["thresholds"]
    d = a["score"] - b["score"]
    arrow = "✅ tốt hơn" if d < -5 else ("⚠️ gần như không đổi" if abs(d) <= 5 else "🔴 tệ hơn")
    L = [f"📊 ĐIỂM MÙI AI: {b['score']} → {a['score']}  ({d:+.1f})  {arrow}", ""]
    L.append(f"{'Chỉ báo':<26}{'Trước':>9}{'Sau':>9}{'Ngưỡng tốt':>15}")
    L.append("-" * 59)
    rows = [
        ("Cụm blacklist /100 từ", "blacklist_per_100w", f"≤ {th['blacklist_per_100w']['good']}"),
        ("Độ dài câu TB (từ)", "avg_sentence_words",
         f"{th['avg_sentence_words']['lo_good']}–{th['avg_sentence_words']['hi_good']}"),
        ("Độ lệch nhịp câu", "sentence_stdev", f"≥ {th['sentence_stdev']['good']}"),
        ("Câu mở bằng liên từ", "transition_ratio", f"≤ {th['transition_ratio']['good']*100:.0f}%"),
        ("Em dash /1000 ký tự", "emdash_per_1000c", f"≤ {th['emdash_per_1000c']['good']}"),
        ("Bullet đều tăm tắp", "bullet_uniformity", f"≤ {th['bullet_uniformity']['good']}"),
    ]
    for name, key, good in rows:
        bv, av = b["metrics"][key], a["metrics"][key]
        if key == "transition_ratio":
            bv, av = f"{bv*100:.0f}%", f"{av*100:.0f}%"
        L.append(f"{name:<26}{str(bv):>9}{str(av):>9}{good:>15}")
    L.append("")
    L.append(f"Số từ: {b['words']} → {a['words']}  "
             f"({(a['words']-b['words'])/b['words']*100:+.0f}%)" if b["words"] else "")
    L.append("")
    L.append("⚠️ Điểm thấp KHÔNG tự động nghĩa là bản mới đúng. Vẫn phải đối chiếu ý gốc ↔ ý mới")
    L.append("   (SKILL.md §4 Bước 3) — cắt chữ thừa ≠ cắt thông tin.")
    return "\n".join(L)


def read_source(path: str | None) -> str:
    if path:
        return Path(path).read_text(encoding="utf-8")
    if sys.stdin.isatty():
        sys.exit("[LỖI] Không có đầu vào. Dùng --file <path> hoặc pipe văn bản qua stdin.")
    return sys.stdin.read()


def main() -> int:
    ap = argparse.ArgumentParser(description="Chấm điểm mùi AI (skill wording-vn)")
    ap.add_argument("--file", help="File cần chấm (bỏ trống = đọc stdin)")
    ap.add_argument("--before", help="Bản gốc — dùng chung với --after")
    ap.add_argument("--after", help="Bản viết lại — dùng chung với --before")
    ap.add_argument("--lang", default="vi", help="Mã ngôn ngữ, mặc định vi")
    ap.add_argument("--json", action="store_true", help="Xuất JSON thay vì bảng")
    args = ap.parse_args()

    cfg = load_patterns(args.lang)

    if bool(args.before) != bool(args.after):
        sys.exit("[LỖI] --before và --after phải đi cùng nhau.")

    if args.before:
        b = analyse(Path(args.before).read_text(encoding="utf-8"), cfg)
        a = analyse(Path(args.after).read_text(encoding="utf-8"), cfg)
        if args.json:
            print(json.dumps({"before": b, "after": a}, ensure_ascii=False, indent=2))
        else:
            print(fmt_compare(b, a, cfg))
        return 0

    r = analyse(read_source(args.file), cfg)
    if args.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print(fmt_report(r, cfg))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
