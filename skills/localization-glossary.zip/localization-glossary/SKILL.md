---
name: localization-glossary
description: >
  Tra cứu thuật ngữ chính thức game Lineage2M (KR↔VN) từ bộ glossary 13.000+ cặp term
  ĐÓNG KÈM ngay trong skill này (data/glossary_central.csv, đã chuẩn hóa 1 KR = 1 VN).
  LUÔN dùng khi: cần dịch tên skill/item/UI/stat/system term KR↔VN; viết hoặc kiểm tra
  content Lineage2M cần đúng thuật ngữ chuẩn; gặp term tiếng Hàn lạ trong patch note,
  roadmap, tài liệu NCSOFT; hoặc khi có người hỏi "term X dịch là gì", "tên VN của Y",
  "KR của Z là gì". Đây là NGUỒN CHÂN LÝ terminology L2M VN — ưu tiên hơn suy đoán hay
  trí nhớ. Tra bằng script hoặc grep, KHÔNG đọc cả file CSV vào ngữ cảnh.
---

# L2M Localization Glossary (bản phân phối — self-contained)

> **Dữ liệu:** `data/glossary_central.csv` — đóng kèm trong gói này.
> **Công cụ tra:** `scripts/lookup_term.py` (Python 3.8+, không phụ thuộc thư viện ngoài).
> **Phạm vi:** 13.000+ cặp term KR↔VN, đã hợp nhất & chuẩn hóa **1 KR = 1 VN** (bản "central").
> **Nguồn gốc:** trích từ file localization chính thức của NCSOFT cho Lineage2M VN.

Skill này **tự chứa dữ liệu** — cài xong là tra được ngay, KHÔNG cần workspace hay mạng.

---

## ⚠️ Quy tắc vàng (đọc trước khi tra)

1. **KHÔNG bao giờ đọc/nạp cả file `data/glossary_central.csv` vào ngữ cảnh.** File có 13.000+ dòng — nạp toàn bộ vừa lãng phí vừa dễ sai. **Luôn tra có mục tiêu** bằng script hoặc `grep`.
2. **Skill này là nguồn chân lý** cho term L2M VN — nếu kết quả tra khác với trí nhớ, **tin kết quả tra**.
3. Nếu tra không ra → thử rút ngắn query / bỏ filter category / đổi `--lang auto`. Vẫn không có → term chưa nằm trong glossary, nói rõ thay vì bịa.

---

## Cách tra cứu

### Cách 1 — Script (khuyến nghị: chạy được ở Cowork bash và code tool của Claude.ai)

Chạy từ thư mục gốc của gói skill:

```bash
# Tra theo KR
python3 scripts/lookup_term.py "파워 스트라이크"

# Tra theo VN (có dấu)
python3 scripts/lookup_term.py "Cường Hóa" --lang vn

# Lọc theo category + giới hạn số dòng
python3 scripts/lookup_term.py "매직" --category SKILL --limit 15

# Khớp chính xác (exact) thay vì chứa (substring)
python3 scripts/lookup_term.py "강화" --lang kr --exact

# Liệt kê toàn bộ category có trong bộ term
python3 scripts/lookup_term.py --categories
```

Script in ra bảng `CATEGORY | KR | VN | NGUỒN` để đọc và dùng trực tiếp.

### Cách 2 — grep (dự phòng khi không có Python)

```bash
# Tra nhanh, không phân biệt hoa thường
grep -i "검사" data/glossary_central.csv

# Chỉ lấy vài dòng đầu
grep -i "enchant" data/glossary_central.csv | head -20
```

CSV có header: `category,kr,vn,source,string_id,resolution_note,note,origin` (cột cần dùng: **kr**, **vn**, **category**).

---

## Tham số của lookup_term.py

| Tham số | Ý nghĩa | Mặc định |
|---|---|---|
| `query` | Term cần tìm (KR hoặc VN) | (bắt buộc, trừ khi `--categories`) |
| `--lang` | `auto` (cả 2 cột) · `kr` · `vn` | `auto` |
| `--category`, `-c` | Lọc theo category (partial: `SKILL` khớp `ACTIVE_SKILL`, `WEAPON_SKILL`…) | không lọc |
| `--limit`, `-n` | Số kết quả tối đa | 30 |
| `--exact` | Khớp trọn term thay vì chứa | tắt |
| `--categories` | Chỉ liệt kê các category | — |
| `--csv` | Trỏ tới CSV khác (nếu tự đặt chỗ khác) | tự tìm cạnh script |

---

## Categories thường dùng

| Category | Mô tả |
|---|---|
| `SYSTEM` | Thuật ngữ hệ thống & Glossary chính thức (Cường Hóa, Tinh Luyện, Thức Tỉnh) |
| `STAT` | Chỉ số nhân vật (ST, Chính Xác, Chí Mạng) |
| `ACTIVE_SKILL` / `WEAPON_SKILL` / `PASSIVE_SKILL` | Tên skill |
| `UI` | Nhãn giao diện, nút bấm |
| `CLASS` | Chủng tộc & class (Nhân Tộc, Tinh Linh, Hắc Tinh Linh) |
| `ITEM` / `EQUIPMENT` / `MATERIAL` | Vật phẩm, trang bị, nguyên liệu |
| `ARTIFACT` / `AGATHION` / `SOULGEM` / `PET` | Trang bị & đồng hành |
| `MONSTER` / `NPC` | Tên quái, NPC |
| `GUILD` | Thuật ngữ bang hội |
| `WORLD` | Tên vùng đất, địa danh |

> `--categories` in đầy đủ danh sách kèm tổng số term.

---

## Khi lookup trả về nhiều VN cho cùng 1 KR

Bộ "central" đã chuẩn hóa 1 KR = 1 VN cho phần lớn term. Nếu vẫn thấy nhiều dòng:

1. Ưu tiên dòng có category `SYSTEM` (termbase chính thức).
2. Kế tiếp là `UI` (đúng thứ người chơi thấy trên màn hình).
3. Đối chiếu cột `origin` / `note` để biết nguồn quyết định.

---

## Lưu ý về dữ liệu

- Đây là **bản chụp (snapshot)** tại thời điểm đóng gói — xem badge **version** trên hub, tải lại khi có bản mới để cập nhật term.
- Là **terminology tham khảo nội bộ** cho công việc NCV/Lineage2M — dùng trong nội bộ, không phát tán ra ngoài.
- Bộ term này KHÔNG chứa dữ liệu người chơi, doanh thu, hay bất kỳ thông tin nhạy cảm nào — chỉ là cặp thuật ngữ KR↔VN.

---

## Changelog

| Ngày | Version | Thay đổi |
|------|---------|----------|
| 2026-07-02 | 1.0 | Bản phân phối đầu tiên. Self-contained: đóng kèm `data/glossary_central.csv` (13K+ term, bản central 1 KR=1 VN) + `scripts/lookup_term.py` portable (đường dẫn tương đối). Là skill data-backed mẫu cho Skill Distribution Hub. |
