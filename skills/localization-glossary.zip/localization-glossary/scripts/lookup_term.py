#!/usr/bin/env python3
"""
lookup_term.py — L2M Glossary Lookup (portable, self-contained)
================================================================
Tra cứu thuật ngữ Lineage2M KR↔VN trong bộ glossary đóng kèm skill này
(data/glossary_central.csv — bản clean, 1 KR = 1 VN).

Chạy được ở mọi nơi có Python 3.8+ (Cowork bash, code tool của Claude.ai, máy cá nhân).
KHÔNG phụ thuộc workspace: tự tìm CSV theo đường dẫn tương đối cạnh script.

Usage:
    python3 lookup_term.py "파워 스트라이크"
    python3 lookup_term.py "Cường Hóa" --lang vn
    python3 lookup_term.py "매직" --category SKILL --limit 15
    python3 lookup_term.py "강화" --lang kr --exact
    python3 lookup_term.py --categories          # liệt kê các category

Author: TuanQG × Claude | L2M Glossary (distributable)
"""
import csv
import sys
import argparse
import re
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent


def find_csv(explicit=None):
    """Tìm data/glossary_central.csv theo layout gói skill (script ở scripts/, data ở data/)."""
    if explicit:
        p = Path(explicit)
        return p if p.exists() else None
    candidates = [
        SCRIPT_DIR.parent / "data" / "glossary_central.csv",  # layout gói: <skill>/scripts + <skill>/data
        SCRIPT_DIR / "data" / "glossary_central.csv",
        SCRIPT_DIR / "glossary_central.csv",
        SCRIPT_DIR.parent / "glossary_central.csv",
        Path.cwd() / "data" / "glossary_central.csv",
        Path.cwd() / "glossary_central.csv",
    ]
    return next((c for c in candidates if c.exists()), None)


def normalize(text):
    return re.sub(r"\s+", " ", str(text).lower().strip())


def load_rows(csv_path):
    with open(str(csv_path), encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def search(rows, query, lang="auto", category=None, limit=30, exact=False):
    qn = normalize(query)
    catf = category.upper() if category else None
    out = []
    for row in rows:
        cat = row.get("category", "") or ""
        if catf and catf not in cat.upper():
            continue
        krn = normalize(row.get("kr", ""))
        vnn = normalize(row.get("vn", ""))
        if exact:
            m = (lang in ("kr", "auto") and qn == krn) or (lang in ("vn", "auto") and qn == vnn)
        else:
            m = (lang in ("kr", "auto") and qn in krn) or (lang in ("vn", "auto") and qn in vnn)
        if m:
            out.append(row)
            if len(out) >= limit:
                break
    return out


def fmt(results, query):
    if not results:
        return (
            f"❌ Không tìm thấy term khớp với '{query}'. "
            f"Thử: rút ngắn query, --lang auto, hoặc bỏ --category."
        )
    lines = [
        f"🔍 '{query}' — {len(results)} kết quả",
        "",
        f"{'CATEGORY':<16} {'KR':<30} {'VN':<38} NGUỒN",
        "─" * 100,
    ]
    for r in results:
        note = r.get("source") or r.get("origin") or r.get("resolution_note") or ""
        lines.append(
            f"{(r.get('category','') or ''):<16} "
            f"{(r.get('kr','') or '')[:29]:<30} "
            f"{(r.get('vn','') or '')[:37]:<38} {note}"
        )
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(
        description="Tra cứu term L2M Glossary KR↔VN",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    ap.add_argument("query", nargs="?", help="Term cần tìm (KR hoặc VN)")
    ap.add_argument("--lang", default="auto", choices=["auto", "kr", "vn"])
    ap.add_argument("--category", "-c", default=None, help="Lọc category (VD: SKILL, UI, SYSTEM, ITEM)")
    ap.add_argument("--limit", "-n", type=int, default=30)
    ap.add_argument("--exact", action="store_true", help="Khớp trọn term thay vì chứa")
    ap.add_argument("--categories", action="store_true", help="Liệt kê tất cả category")
    ap.add_argument("--csv", default=None, help="Đường dẫn CSV (mặc định: tự tìm cạnh script)")
    args = ap.parse_args()

    csv_path = find_csv(args.csv)
    if not csv_path:
        print(
            "ERROR: Không tìm thấy data/glossary_central.csv cạnh script.\n"
            "       Hãy giải nén NGUYÊN gói skill (giữ thư mục data/)."
        )
        sys.exit(1)

    rows = load_rows(csv_path)

    if args.categories:
        cats = sorted({(r.get("category", "") or "") for r in rows if r.get("category")})
        print(f"{len(cats)} categories ({len(rows)} terms tổng):")
        print(", ".join(cats))
        return

    if not args.query:
        ap.error("thiếu 'query' (hoặc dùng --categories)")

    print(fmt(search(rows, args.query, args.lang, args.category, args.limit, args.exact), args.query))


if __name__ == "__main__":
    main()
